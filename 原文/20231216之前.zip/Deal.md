# 如何评价曹保平执导，黄渤、周迅主演的电影《涉过愤怒的海》？

\#Deal#

关于爱，有一个关键的问题，是它不是一种有固定质量标准的标准服务。

有一个著名的比喻—— 一个穷寡妇捐赠的两个铜板和一个富人捐赠的二两银子，孰重孰轻？

结论是——穷寡妇的两个铜板的分量是有加权的，因为可能那是她的全部财产。

很可能你贫穷、见识浅薄的父母给你的爱让你非常不舒服、甚至对你造成很多痛苦，但是ta们如果尽了力、是真诚的，在上天的眼里，这仍然是算为爱的。

如果你羡慕别人的父母见多识广、高雅多金，给了别人很多你万分羡慕的好处，于是反过来认定父母没有给你爱，你就是在按照“爱有基本的效果上的标准，无论你有多尽力，只要没到一定的客观效果，都不能算爱”的方法论在看待爱的问题。一旦这样看待问题，就会产生“缺爱”的困境。

这个困境还不止是简单的“我觉得被父母亏欠”而已，它的影响比这深远的多。

这个思考问题的方式，会自然而然的产生一个隐性的观点——“我应该得到一个特定质量、特定数量的善待”。也就是世界整体上立刻欠了自己一笔“善待债”。

这份债务如果数量减少，那么质量就要提高，如果供应人数减少，那么每人平均供应量就要提高。总之，我要这么多的好，不管谁来、不管分几次，总之要给我，这个总量我要保证，否则我就要[愤怒](https://www.zhihu.com/search?q=愤怒&search_source=Entity&hybrid_search_source=Entity&hybrid_search_extra={"sourceType"%3A"answer"%2C"sourceId"%3A3314814780})，要失望，我就要惩罚……惩罚谁再说，总之我要做点什么[惩罚](https://www.zhihu.com/search?q=惩罚&search_source=Entity&hybrid_search_source=Entity&hybrid_search_extra={"sourceType"%3A"answer"%2C"sourceId"%3A3314814780})性的事。

这个念头一旦确立，就会立刻将这笔债务摊派到所有社会关系人身上，父母有父母的份额、恋人有份额、同学有份额、同事有份额……社会关系网上的每一个与我关联的节点，都有一份需要完成的工作量。

而这个想法会产生一个可怕的[滚雪球效应](https://www.zhihu.com/search?q=滚雪球效应&search_source=Entity&hybrid_search_source=Entity&hybrid_search_extra={"sourceType"%3A"answer"%2C"sourceId"%3A3314814780})——如果需要分担这个任务量的人一共有十个，那么当其中一个没有完成ta的配额，剩下的九个人就要自动面对更大的任务要求。有两个不达标，那就是八个人分十个人的量。要再有人逃跑，那就是七个人分这十个人的量。

你看出这个[数学趋势](https://www.zhihu.com/search?q=数学趋势&search_source=Entity&hybrid_search_source=Entity&hybrid_search_extra={"sourceType"%3A"answer"%2C"sourceId"%3A3314814780})指向何方了吗？

这就是为什么一旦采纳了“爱是一种标准服务”的思想，而又一旦遭遇了“有人未按期待提供服务”的问题，就会启动一个可怕的[单向进程](https://www.zhihu.com/search?q=单向进程&search_source=Entity&hybrid_search_source=Entity&hybrid_search_extra={"sourceType"%3A"answer"%2C"sourceId"%3A3314814780})。

逐级放大的人均要求，会将剩下的人压得更加喘不过气来，逼得剩下的人更想逃。

雪球越晚下滚，越是势不可挡。

当事人自己也不是对这个趋势完全茫然，所有这样做的人都会本能采用对抗性的措施来平衡这种雪球效应——那就是当十个人减为九个，我也会吧原本会分给十个人的回报分摊到剩下的九个人身上，这不就平衡住了吗？

剩下八个的时候，我也就变成只对你们八个人好，剩下七个的时候，我也就只对你们七个好……以此类推。这样，你们的人均负担是加大了，但是你们的[人均回报](https://www.zhihu.com/search?q=人均回报&search_source=Entity&hybrid_search_source=Entity&hybrid_search_extra={"sourceType"%3A"answer"%2C"sourceId"%3A3314814780})也提升了呀。

我们先假设这个基本逻辑的确成立——如果[收支平衡](https://www.zhihu.com/search?q=收支平衡&search_source=Entity&hybrid_search_source=Entity&hybrid_search_extra={"sourceType"%3A"answer"%2C"sourceId"%3A3314814780})，那么就可以维持关系稳定。

然后我们再往下看。如果这八人也和你有一样的“标准爱”观念，那么你很难保证这八个人全都对自己的收支全都感到满意。其中很可能有几个人对“及格的爱”的标准要求很高，远超过你自己的及格标准。

于是按这几个人的看法，你何止没有补全ta们的付出，你干脆可以算是[恩将仇报](https://www.zhihu.com/search?q=恩将仇报&search_source=Entity&hybrid_search_source=Entity&hybrid_search_extra={"sourceType"%3A"answer"%2C"sourceId"%3A3314814780})的。于是又有那么一两个人拔腿走人了。

这时候你就要意识到问题严重了——十一个人摊十二个人的份额，每个人增加的量还好，也许都没超过[统计误差](https://www.zhihu.com/search?q=统计误差&search_source=Entity&hybrid_search_source=Entity&hybrid_search_extra={"sourceType"%3A"answer"%2C"sourceId"%3A3314814780})。但是五个人摊六个人的量呢？四个人摊五个人的量呢？这可是一下增加25%的压力。

你能及时的增大你的付出量，去平衡这剩下的人的负担吗？

尤其是，很多年轻人会自然而然的发现这样[分散交易](https://www.zhihu.com/search?q=分散交易&search_source=Entity&hybrid_search_source=Entity&hybrid_search_extra={"sourceType"%3A"answer"%2C"sourceId"%3A3314814780})的交易成本太高，不如干脆把所有的好都集中到一两个人身上，然后把所有的负担也都放在这一两个人肩上。甚至是全都集中在一个人身上。

**你帮我扛整个世界的欠我的债，我给你全部我能给的奖励 —— Deal？ Or no deal？**

看到问题了吗？当你这样逼问一个人，这个人或迟或早，都会退出这种交易。就算是一开始是答应的，ta也扛不了多久。

一旦你认定爱是一种标准服务，达不到这个标准就不算爱。你就会被难以抗拒的客观逻辑一路顺着这条高速公路送到这个挨个逼问“唯一救星”们是否接受这种交易的境地。

而ta们几乎必然或迟或早的一个又一个的选择退出，直到你丧失询问下一个新“救主”的勇气。

看清楚，这是**[数学证明](https://www.zhihu.com/search?q=数学证明&search_source=Entity&hybrid_search_source=Entity&hybrid_search_extra={"sourceType"%3A"answer"%2C"sourceId"%3A3314814780})**。你不服没用，拉上再多的同道“抗争”，也没用。



爱不是你可以随便自己定义的东西，定义错了就会一路滑向深渊。

你可以说“某人给你的爱并未让你觉得快乐”——这是一个客观事实——但不能因此就连一个确认对方爱你的句子都造不出来。

这看似是无关紧要的区别，

但这区别最后导致的结果，

却可能相差十七刀。

