chenqin的回答如下：

https://www.zhihu.com/question/533037443/answer/2490856319?utm_source=zhihu&utm_medium=social&utm_oi=56667265826816

网友：

太奇怪了。。。
又没有给数据来源，图又很生草，评论区又不交流。。。
最后两张图问题那么大，Y轴都不一样，拿来直接给结论。。。
还有那么多赞。。。
太奇怪了。。。

JH：

基本属于懒学术，即使不考虑数据来源问题，他的论据也支持不了他的结论。

