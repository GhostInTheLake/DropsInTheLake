# YadaYada

Tags: **Changes**

> 德国宣布驱逐 40 名俄罗斯外交官，释放了什么信号？



Yada yada yada…

Ya, we are evil,

we are savages,

we are the devil in flesh.

We get it, really.

Stop this shit already.

We don’t want to sound like a sexist,

but 

**BE A MAN, will you?**

  
What are you expecting?

Some dolly-eyed country switches side over this?

The game is on,

and sides are taken.

No one is coming,

just you and us.

Just throw every thing you get at me,

you 

spineless 

brainless 

shameless 

COWARD.

  
  


其实还是那句话，欧洲制裁俄罗斯越多、越彻底，

**俄的行动越自由，可选的反击工具就越丰富、反击的主动性越强，**

**将来欧洲妥协的代价就越高。**

**这实际上是一种资敌。**

比如，俄罗斯“鉴于西方一些国家的不友善行为，普京已指示专门委员会制定“二级不友好国家名单”，然后告诉这些国家“必须直接用卢布付款，不适用代兑换模式”。

这些国家就要为这些口舌之利付出巨大的、真金白银的现实代价。

将来要妥协时就要付出更大的成本去修复关系。

二级之上还有三级，三级之上还有四级。

整数是用不完的。

总之核弹已经起竖，经济已经准备彻底脱钩。你只剩叫，我却可以还以寒冷、饥饿和现实威胁。

  


**和一个自己打不死、离不开的对手结仇越深，挑衅越狠，将来到了“离不开”“打不死”的事实卡在眼前，堵在自己整个历史进程的去路上的时候，要付出的代价越高。**

  


欧洲最近又是与俄罗斯决裂，又是在中国面前大谈“must”，实在是有点脱离现实太远了。自己站在坑里，还在不停的挖土往别人身上抛，以为得胜。

只能说命该如此，看ta们自己的老百姓将来怎么评价这群人吧。

这次大战过后，欧洲可能会陷入对民主制度的深刻幻灭。

我的判断没变——西方集团赢不了。

整个第三世界对这一点看得越来越清楚了。西方集团闹得越大声，第三世界心越定。

提醒欧洲一声——中国疫情严重，可以预见很快**客观上会**对欧洲和美国中断物资供应。

其效果与禁运本质相同——难道你们要禁止我们防疫？

前所未有的能源、粮食、工业组件、生活用品以及军事安全的大短缺即将同时到来。

而你们在威胁、恐吓所有可能救你们的国家。

它们早已接受了“别描了，我们是恶魔”的设定，根本不关心你这些威胁和恐吓有多大自以为的“正当性”。

问题是这是些手握粮食、能源、物资和市场的恶魔。

欧洲这是要“不食周黍而死”吗？

  


Keep it real, bro.

’cause this shit is about to get real.



