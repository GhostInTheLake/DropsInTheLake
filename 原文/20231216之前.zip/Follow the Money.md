# 数百名 OpenAI 员工致信董事会，要求恢复奥特曼职位，将带来哪些影响？

\#Follow the Money#

为什么这些人这么热爱Altman？

[灵动未来股权激励：OpenAI的股权结构，很不一般zhuanlan.zhihu.com/p/614263736?utm_id=0](https://zhuanlan.zhihu.com/p/614263736?utm_id=0)



![img](https://picx.zhimg.com/80/v2-d6e61f807758f3ba90c5bb1947ffc51c_720w.webp?source=2c26e567)

因为Altman力求尽快[融资](https://www.zhihu.com/search?q=融资&search_source=Entity&hybrid_search_source=Entity&hybrid_search_extra={"sourceType"%3A"answer"%2C"sourceId"%3A3296271966})的策略有利于公司估值和尽快进入返利给员工的阶段。

其实openAI在签订这份“巧妙的协议”的时候，就已经埋下了这颗种子。

坦率讲，ai的工作只要想走正路，就只有开源一条路，一旦起了心思闭源，你必定要遇到“资源不足，必须融资”的问题，而只要你融资，即使你绞尽脑汁，签出这样的协议，也一样会导致组织成员面临巨大的[利益](https://www.zhihu.com/search?q=利益&search_source=Entity&hybrid_search_source=Entity&hybrid_search_extra={"sourceType"%3A"answer"%2C"sourceId"%3A3296271966})考验。

到时候要坚持理想，就会令已经潜在成为亿万富翁的成员们一夜回到“[君子固穷](https://www.zhihu.com/search?q=君子固穷&search_source=Entity&hybrid_search_source=Entity&hybrid_search_extra={"sourceType"%3A"answer"%2C"sourceId"%3A3296271966})”的状态。

你信不信——ta们中的很多人都已经把这份理论上十拿九稳的钱花掉了，已经变成别墅、跑车和“[长期投资](https://www.zhihu.com/search?q=长期投资&search_source=Entity&hybrid_search_source=Entity&hybrid_search_extra={"sourceType"%3A"answer"%2C"sourceId"%3A3296271966})”了。

你现在告诉他们公司[估值](https://www.zhihu.com/search?q=估值&search_source=Entity&hybrid_search_source=Entity&hybrid_search_extra={"sourceType"%3A"answer"%2C"sourceId"%3A3296271966})要从明天预估900亿变成500亿，ta们的理想程度可能会令你非常失望。

很多人都误认为这些员工“集体请愿”是出于对Altman的“爱戴”，这是个过于美好和清纯的想法。

不过，既然openai是在[美国](https://www.zhihu.com/search?q=美国&search_source=Entity&hybrid_search_source=Entity&hybrid_search_extra={"sourceType"%3A"answer"%2C"sourceId"%3A3296271966})的土壤和文化里诞生的，这一开始就差不多是它注定的宿命。

它终将因为资本而变得平庸。

再说一遍，真正精纯的理想，才是革命性创新的资格。

不是资本。

