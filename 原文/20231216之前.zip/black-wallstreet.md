# Black Wallstreet

Tags: **Society**

> 黑人有没有可能自己建一个州？



了解一下Tulsa “Black Wallstreet” Massacre。

那是历史上黑人最接近凭借诚实努力、依法经营在一个地区真正占据优势、形成有效控制的一刻。

这个地区聚集了四面八方而来的黑人精英，经济上相当繁荣而且自给自足。在市场上也有相当强的竞争力。

黑人们抱着强烈的希望，想要形成自己的社区，自己在美国的家园。

甚至从一战战场上回乡的黑人士兵们自发的在这个地区组织了一支半正规的自卫部队。

失败了。

  


![](https://pica.zhimg.com/50/v2-227e2eb74f857dc7f5b461c8ec69ffa8_720w.jpg?source=1940ef5c)  


![](https://pic2.zhimg.com/50/v2-e5a672a3d01b431c7df33d085ca97253_720w.jpg?source=1940ef5c)  


![](https://pica.zhimg.com/50/v2-81243092654cd4e6be9a42dea72091d6_720w.jpg?source=1940ef5c)**这个地方，是川普连任竞选的集会起点。就在今天。**
---------------------------

![](https://pic1.zhimg.com/50/v2-0696d7a65c51401b89a0c0cfba634fdb_720w.jpg?source=1940ef5c)多年以后，人们回忆起今天，可能会发现到这是美国一个值得记录的原点。

今天，秋风起于青萍之末。

[【Vox】塔尔萨种族大屠杀——黑色华尔街消亡\_哔哩哔哩 (゜-゜)つロ 干杯~-bilibili](https://link.zhihu.com/?target=https%3A//m.bilibili.com/video/BV1yb411b7Ng%3Ft%3D501)感谢评论区 [@冰原](https://www.zhihu.com/people/a575e230cbbdee1b5c59342e3531834b) 提供链接



