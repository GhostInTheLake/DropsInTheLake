# AutoGPT 是什么？它有哪些应用场景？

\#autoGPT#

这玩意在大多数情况下都会走入莫名其妙的死循环或者输出荒腔走板的结果——因为它所谓的自我引导，极大的依赖于典型需求的[数据高频性](https://www.zhihu.com/search?q=数据高频性&search_source=Entity&hybrid_search_source=Entity&hybrid_search_extra={"sourceType"%3A"answer"%2C"sourceId"%3A2987136199})。

对频率不高的需求，ai很难从中捕获规律，形成有效的自我引导。

然而，你看到什么使用冷门需求的autoGPT测试视频了吗？

这类视频没人愿意点赞转发，推荐[算法](https://www.zhihu.com/search?q=算法&search_source=Entity&hybrid_search_source=Entity&hybrid_search_extra={"sourceType"%3A"answer"%2C"sourceId"%3A2987136199})很自然的不会引流，制作者会亏本。



客观来讲，现在媒体在有意无意的迎合公众的恐慌和憧憬情绪。

现在ai领域存在着“拿理想案例吹嘘造势，再拿公众不理智的乐观情绪作为证据，尝试与投机性极强的资本联手做局收割公众投资者”的很强的嫌疑。

这是在新概念出现时必然会借着资本主义市场经济运行机制爆发一轮的制度恶疾，和[计划经济](https://www.zhihu.com/search?q=计划经济&search_source=Entity&hybrid_search_source=Entity&hybrid_search_extra={"sourceType"%3A"answer"%2C"sourceId"%3A2987136199})很容易爆发一轮偏补潮一样，属于[制度性](https://www.zhihu.com/search?q=制度性&search_source=Entity&hybrid_search_source=Entity&hybrid_search_extra={"sourceType"%3A"answer"%2C"sourceId"%3A2987136199})的内在缺陷必然会受到的利用。

这个时候的主流声音一定会不自觉的合谋，构建一个远超实际的幻觉。因为ta们发现，无论是为了真金白银的获得[融资](https://www.zhihu.com/search?q=融资&search_source=Entity&hybrid_search_source=Entity&hybrid_search_extra={"sourceType"%3A"answer"%2C"sourceId"%3A2987136199})还是为了获得流量、话语权，创造、维持和扩大这个幻觉对这个生态的每一个早期玩家都有好处。

它们已经发现这合法的技巧——通过“原型阶段”的借口把体验弄得非常复杂，并通过“算力不足，限制服务”的巧妙理由，可以长期把主要使用者有效的限定在有大量时间投入新玩具的特殊人群身上。而因为人的固有心理规律，这些最早被邀请的特殊嘉宾陷入了一个意识游戏之中——ta们会不由自主的成为共同利益人。

侦察兵会有“如果什么都没看到意味着我失败了”的想法，探险家会有“什么都没找到意味着我浪费了所有的预算”的压力。

他们会不由自主地极力挖掘亮点，并且避开大量的问题和风险不谈，并且这种行为还会有交互的示范性和[传染性](https://www.zhihu.com/search?q=传染性&search_source=Entity&hybrid_search_source=Entity&hybrid_search_extra={"sourceType"%3A"answer"%2C"sourceId"%3A2987136199})——张三写了个完美测试，[李四](https://www.zhihu.com/search?q=李四&search_source=Entity&hybrid_search_source=Entity&hybrid_search_extra={"sourceType"%3A"answer"%2C"sourceId"%3A2987136199})马上会想法子换皮复现。专挑“几句话做一个网站”这种实际上精心选择的任务来此起彼伏的鼓吹，而用一些极简短的话来含糊其辞的略去极其大量的其他任务的荒唐的失败。

不是没有人会直言不讳陛下的长袍只盖住了肚脐眼，但是所有在场的人，包括前排围观、等着欢呼的群众都会不由自主的无视和忽略这些声音。

因为这太扫兴了，太不合时宜。



和历史上曾经出现的各种革命性的技术一样，AI[大概率](https://www.zhihu.com/search?q=大概率&search_source=Entity&hybrid_search_source=Entity&hybrid_search_extra={"sourceType"%3A"answer"%2C"sourceId"%3A2987136199})既不会像现在你所想象的那么强大，也远不会像你亲手使用后所失望的那么无能。

它大概会在两个方向都让人意外。

这一次，也许是叠加上了美国自身的深刻经济和社会危机，对于AI题材的市场操纵和炒作有比较明显的不健康倾向。“内部[测试](https://www.zhihu.com/search?q=测试&search_source=Entity&hybrid_search_source=Entity&hybrid_search_extra={"sourceType"%3A"answer"%2C"sourceId"%3A2987136199})视频”早早泄露和正式产品与其功能复杂度不相称的拖延发布之间存在着危险的信号，有一种推迟真相的到来，利用好这段可以操纵的时期尽量推高[股价](https://www.zhihu.com/search?q=股价&search_source=Entity&hybrid_search_source=Entity&hybrid_search_extra={"sourceType"%3A"answer"%2C"sourceId"%3A2987136199})和吸收投资的味道。



尽早全面[上市](https://www.zhihu.com/search?q=上市&search_source=Entity&hybrid_search_source=Entity&hybrid_search_extra={"sourceType"%3A"answer"%2C"sourceId"%3A2987136199})，让消费者直接用起来，你才会有真实的评价。

现在先不要急着看图说话。

稍安毋躁。

