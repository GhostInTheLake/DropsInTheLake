# 为什么有很多女孩相信"girls help girls"这种观点？

\#ToTheEnd#

怎么，没带卫生巾，是男士们要挺身而出了？唇膏丢了，是哪位大兄弟要慷慨分享了？发现经期异常，是你要当知心大哥？没有奶，是你要当催奶顾问？你要帮她分析怎么处理[性骚扰](https://www.zhihu.com/search?q=性骚扰&search_source=Entity&hybrid_search_source=Entity&hybrid_search_extra={"sourceType"%3A"answer"%2C"sourceId"%3A2543797753})？你要陪她去谈恋爱？

女生不帮女生，你来？

你再说一遍，是不是要禁止女生帮助女生？

为了自己那点事，为了自己的欲望，居然要干预到人家从哪里获得帮助？

说出来不觉得有问题吗？





知乎现在流行着一种神奇的风气——连忠于祖国、见义勇为、努力奋斗、生育子女、尊敬父母、宽容他人、尊重信仰自由、民族团结、乐于助人、女性应该帮助女性……这样的价值观都要攻击。

一条两条也就罢了，当你发现**条条都有你**，你难道没感觉到这有点问题吗？

真的一点都没觉察到这个状态**不健康**吗？

当你发现某个人，条条都有ta，你不觉得你**总是赞同ta，**不是一个好兆头吗？

反对啊，反对啊，一条两条也就罢了。

**条条都反对**，[势不两立](https://www.zhihu.com/search?q=势不两立&search_source=Entity&hybrid_search_source=Entity&hybrid_search_extra={"sourceType"%3A"answer"%2C"sourceId"%3A2543797753})的反对，要召集兄弟们骂死ta打死ta的那样反对。

一路反对下去。

To what end, bro?



这些反对、咒骂、攻击的快感你领取了，这些东西你就自动摒弃了。

都摒弃了，**换成什么**？



**To what end？**

Bro？



你能坐好了想想吗？

