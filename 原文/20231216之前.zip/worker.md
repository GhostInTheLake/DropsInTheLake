# 三百万放银行吃利息，我可以不用上班吗？

\#WORKER#

There is a certain kind of happiness that I hope you will not miss: being a WORKER.

I do not mean labor, nor job, affair, business, or even duty.

I mean, please, work on something hard, persistent, with resilience, to the limit, and go beyond those limits.

A worker is not “a person who lives on salary.”

NO, NOT AT ALL.

A worker is a person who makes something work, just like a cooler is a tool that makes something cool.

“Coincidentally”, Making something work is exactly the very work of GOD, which makes every common worker, even the most insignificant one, a true colleague of the world's creator.

It’s the second most incredible honor a mortal being can hope and reach for, right after a man of [charity](https://www.zhihu.com/search?q=charity&search_source=Entity&hybrid_search_source=Entity&hybrid_search_extra={"sourceType"%3A"answer"%2C"sourceId"%3A2777702915}), which is become the likes of GOD.

Some day, you will understand it [preserves](https://www.zhihu.com/search?q=preserves&search_source=Entity&hybrid_search_source=Entity&hybrid_search_extra={"sourceType"%3A"answer"%2C"sourceId"%3A2777702915}) an even greater value than life itself, so “there is no satisfying return” is not a good enough reason to abandon this pursuit.

It’s one of the greatest JOY you should not miss.

If you have 3 million in your bank account, what you have is actually 3 million reasons to enjoy it most dearly and immediately.

If you don’t have that money, or hell, broke as shit, you have an even more obvious reason to work.

Focus on the true nature of work, it will provide.

The world is hard-wired that way to make sure every colleague of his is cared for.

Sadly, those who “bear labor for bread” are not considered as one of them.

They are bearing labor alright,
but they rarely have that “bread.”

