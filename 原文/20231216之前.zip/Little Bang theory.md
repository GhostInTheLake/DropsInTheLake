# 假设宇宙飞船在以百分之一的光速飞行，在飞行过程中遇到了一个静止钨元素为主的小陨石？当前材料是否能防护？

\#Litttle Bang theory#

[亚光速](https://www.zhihu.com/search?q=亚光速&search_source=Entity&hybrid_search_source=Entity&hybrid_search_extra={"sourceType"%3A"answer"%2C"sourceId"%3A3000584911})飞行的飞船会在前方维持一架“护盾无人机”。在进入[匀速飞行](https://www.zhihu.com/search?q=匀速飞行&search_source=Entity&hybrid_search_source=Entity&hybrid_search_extra={"sourceType"%3A"answer"%2C"sourceId"%3A3000584911})后，只需要轻轻一推，这架尖锥状的、接近纯壳体+[姿态发动机](https://www.zhihu.com/search?q=姿态发动机&search_source=Entity&hybrid_search_source=Entity&hybrid_search_extra={"sourceType"%3A"answer"%2C"sourceId"%3A3000584911})的无人机就会在主飞船前方当这个“替死鬼”。

而就是这个“铁头替死鬼”用的也不会是[刚性防护](https://www.zhihu.com/search?q=刚性防护&search_source=Entity&hybrid_search_source=Entity&hybrid_search_extra={"sourceType"%3A"answer"%2C"sourceId"%3A3000584911})的逻辑，而更可能是自己也放出一串连动力都没有的先导碰撞体，给自己在前面开路。

即便是主飞船本身，在这个阶段也会自我解体成为一个[直线队列](https://www.zhihu.com/search?q=直线队列&search_source=Entity&hybrid_search_source=Entity&hybrid_search_extra={"sourceType"%3A"answer"%2C"sourceId"%3A3000584911})，一个接一个，互相保持间距躲在护盾的后面。以保证最大限度的幸存率。

到了减速阶段，才会由动力舱段出发去把大家一个个的接回来，实施总体减速。

简单来说，在路边不知情的王大爷看来，你的飞船/船队，才是这个故事里的“陨石群”。

王氏研究院还专门写了一篇“超新星抛出物线列状解体机制“的论文。

史称“little bang theory”。

![动图封面](https://pica.zhimg.com/50/v2-2d51e4f687290e1a8c462e149a3f5488_720w.jpg?source=1940ef5c)

