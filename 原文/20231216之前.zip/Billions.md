# 官方通报北极鲶鱼事件，深圳市原交通局货运管理分局局长被开除党籍并收缴其违纪违法所得，哪些信息值得关注？

\#Billions#

如果你了解监察部门的行事逻辑，你就知道现在的结果绝不是一些不懂行的人想的所谓的“轻描淡写”。这整个家族在中国能力所及范围内的财产、企业、职权，估计已经哀鸿遍野了。

[国有企业](https://www.zhihu.com/search?q=国有企业&search_source=Entity&hybrid_search_source=Entity&hybrid_search_extra={"sourceType"%3A"answer"%2C"sourceId"%3A3244814726})、事业单位的风声很灵的，你爹被调查且定性，你的各种投标都别想了还是轻的，你很多现有业务的回款、续签都基本完蛋。

就算是私营企业，只要是上市企业或者有头有脸的都会严肃考虑要不要再跟你沾边。

you are radioactive，不拿铅板挡起来，我怕我要得[癌症](https://www.zhihu.com/search?q=癌症&search_source=Entity&hybrid_search_source=Entity&hybrid_search_extra={"sourceType"%3A"answer"%2C"sourceId"%3A3244814726})。

问题是这算是“集体迫害你”吗？这只不过是人家最正当的自我保护、趋利避害而已好吗？咋的，难道你不许人家考虑自己的企业品牌和经营安全？你在美国卷入巨大敏感争议还不是一样？

而且这些效应还等不到你被定性，你一进去，就已经开始生效了。眼见得业务急剧萎缩、股价跳水、流动资金迅速枯竭、银行信贷完全停顿。

这哪是几百万、上千万就能解决的问题。

要是坐牢就能立马解决问题，老爷子只怕马上就愿写申请书去坐牢了，要是交罚款就能“算了”，人可以把签字栏都签穿。

问题是人家要的是“[退赃](https://www.zhihu.com/search?q=退赃&search_source=Entity&hybrid_search_source=Entity&hybrid_search_extra={"sourceType"%3A"answer"%2C"sourceId"%3A3244814726})”、“老实交代问题”。交钱本身就会导致被定性，还有一个“这钱是亏掉划算还是交掉划算”的纠结势必要权衡辗转几个月甚至一两年。

这个过程，不需要再增加任何其他措施，就会形成让你终身难忘的体验。这种传递到全家族每一个人每一次呼吸的压力，绝不是什么“我润到国外了”就可以嬉笑以对的。

否则现在不是当事人已经“移民”了吗？难道还怕我们学[印度](https://www.zhihu.com/search?q=印度&search_source=Entity&hybrid_search_source=Entity&hybrid_search_extra={"sourceType"%3A"answer"%2C"sourceId"%3A3244814726})派特工去刺杀不成？但你看ta们有继续在外网叫嚣吗？

所谓“逃到海外”，对这种家族来说跟“流亡待死”没什么本质区别。光有钱，没有本地的根基，这些钱只是当地律师医生理财[瑜伽](https://www.zhihu.com/search?q=瑜伽&search_source=Entity&hybrid_search_source=Entity&hybrid_search_extra={"sourceType"%3A"answer"%2C"sourceId"%3A3244814726})心灵等各路“大师”们的肉菜。人生存靠的不是钱，而是社会根基。[社会根基](https://www.zhihu.com/search?q=社会根基&search_source=Entity&hybrid_search_source=Entity&hybrid_search_extra={"sourceType"%3A"answer"%2C"sourceId"%3A3244814726})就像一个桶，钱只是桶里装的水。有了桶，接雨水你也渴不死。没有这个桶，首先你手里的水你就碰不住要哗啦流一地。然后你想再攒雨水去换一个桶，那就要看你还有没有上次那么好的运气了。

这么说吧，你要[马斯克](https://www.zhihu.com/search?q=马斯克&search_source=Entity&hybrid_search_source=Entity&hybrid_search_extra={"sourceType"%3A"answer"%2C"sourceId"%3A3244814726})这种靠本事发家的，净身出户也很快重新崛起。问题是你是吗？你是被风吹上天的[那啥](https://www.zhihu.com/search?q=那啥&search_source=Entity&hybrid_search_source=Entity&hybrid_search_extra={"sourceType"%3A"answer"%2C"sourceId"%3A3244814726})，你现在再蹲个风口看看，你看这回出来的是风还是火？

这些处置信息，不明白厉害的平民老百姓和小朋友们看着不过瘾而已，ta们想看的是祖国人眼射[激光](https://www.zhihu.com/search?q=激光&search_source=Entity&hybrid_search_source=Entity&hybrid_search_extra={"sourceType"%3A"answer"%2C"sourceId"%3A3244814726})切成八块。

多看Billions，少看Bad Boys。

前者才是真狠人，祖国人[心理年龄](https://www.zhihu.com/search?q=心理年龄&search_source=Entity&hybrid_search_source=Entity&hybrid_search_extra={"sourceType"%3A"answer"%2C"sourceId"%3A3244814726})才八岁。



不要打着靠贪污发家的主意，那后面的折磨，不比流汗打工来得少。那些恐惧落到你头上，你会知道什么“抑郁症”纯属过家家。

否则寺庙道观何以香火如此鼎盛呢？

