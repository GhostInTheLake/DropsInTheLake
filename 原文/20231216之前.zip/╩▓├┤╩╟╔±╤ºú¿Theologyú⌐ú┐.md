# 什么是神学（Theology）？

要定义“神学”，首先要定义“神”。

[神的存在性的实质是什么？786 赞同 · 835 评论回答![img](https://pic4.zhimg.com/v2-9182986ecc830a9327c4787e2b43cfe7_180x120.jpg)](https://www.zhihu.com/question/21446833/answer/545409161)

神有一种本质的定义，即“神圣意志”的总和。

而“神圣意志”的直接体现，就是作为这个世界的纲领的、不可抗拒的自然法。

神学，本质上是在谈论这些[自然法](https://www.zhihu.com/search?q=自然法&search_source=Entity&hybrid_search_source=Entity&hybrid_search_extra={"sourceType"%3A"answer"%2C"sourceId"%3A1213887662})中内蕴的一种底层逻辑——何以世界会是这样、何以自然规律会是这样、社会的运行逻辑会是这样、人的意志构造会是这样……的一种底层逻辑。

从这个层面上讲，神学即是关于规律之规律的假说——这就是最广义的神学。

背后的这个底层逻辑，因为其唯一的[观测者](https://www.zhihu.com/search?q=观测者&search_source=Entity&hybrid_search_source=Entity&hybrid_search_extra={"sourceType"%3A"answer"%2C"sourceId"%3A1213887662})只能是身为[智能体](https://www.zhihu.com/search?q=智能体&search_source=Entity&hybrid_search_source=Entity&hybrid_search_extra={"sourceType"%3A"answer"%2C"sourceId"%3A1213887662})的人类，而人类的成型过程又必然限定了人类的认识方式。这种认识方式将不可避免的看见这“底层逻辑”背后的“人格”。并且也不可避免的看到这个“拥有人似的性格”的底层逻辑的“行为”是理解历史最简洁的主线。

关于历史，人只有两种可能的立场选择——历史或者是无意义的、随机的，或者便是有意义的，有目的的。

**前一种立场必定将人生的意义一同陪葬。**只要你采取这个立场，在你的力量已经不足以抵挡痛苦，只能依靠意义救赎痛苦的时候，你就无可救赎。因为无可救赎，每一秒钟你都将面对“为什么还要活着受罪，这样有何意义”的质问。

你既答不出来，也没勇气去死，唯一的“依靠”不过是一天比一天更少出现、也更寡淡的偶然快感。如果你同意这是不可选择的，那么就等于这个问题其实只有第二个答案。

唯有意义能让你的生命值得忍受，而要人生有意义，历史必须有意义。

历史要有意义，则自然法必须是意志的体现，历史必然是这个意志的体现。

唯一的争论，只不过是这个意志是否具有能动性。

认定其不具备能动性，则这个意志早已离场。现在仍在运转的一切，不过是在顺从它的“遗愿”。这其实就是“[无神论](https://www.zhihu.com/search?q=无神论&search_source=Entity&hybrid_search_source=Entity&hybrid_search_extra={"sourceType"%3A"answer"%2C"sourceId"%3A1213887662})”的本质。

认定其具有能动性，则这个意志是动态的，仍然每时每刻在沿着祂的目的在行动。这就是“[有神论](https://www.zhihu.com/search?q=有神论&search_source=Entity&hybrid_search_source=Entity&hybrid_search_extra={"sourceType"%3A"answer"%2C"sourceId"%3A1213887662})”的本质。

看到了吗？

实际上无神论和有神论真正的区别并不在于那个意志是否存在，也不在于那个意志是否真的具有人格，而在于祂的“死活”。

认定祂已死，你就会得到“[斯宾诺莎](https://www.zhihu.com/search?q=斯宾诺莎&search_source=Entity&hybrid_search_source=Entity&hybrid_search_extra={"sourceType"%3A"answer"%2C"sourceId"%3A1213887662})的上帝”，一个等效于静止不变的自然规律的、无意义的、无态度的遗物。这与认定祂不存在并没有本质的区别。

认定祂仍活着，你就会得到人格化的上帝——但实际上这个存在远非人格所能概括，只是人类只能用自己的思维透镜去观看祂，而这透镜必然将它的神格人格化罢了。

为了你自己的存在，你的痛苦必须有意义；你的痛苦要有意义，历史必须有意义；历史要有意义，主导历史的自然法必须有意义；自然法要有意义，则自然法必须是某种意志的体现。

意志既然有体现，那么这个意志的特征、过去、现状和未来，就可以成为研究的对象。

这种研究，就是神学。

神学即意义之源。

------

神学有时代性。

在过往的时代，有过往时代的神学。它在自己所在的时代解决了意义问题。在新的时代，有新的神学，同样要负责在新的时代解决意义问题。每个时代的神学，必须战胜时代所提出的质疑和挑战，旧的如此、新的亦然。

现代神学并不依赖圣经去理解上帝，而是以圣经为课题来源，循着客观世界去理解上帝——这不是什么标新立异的智能之士的虎皮大旗，而是**上帝通过塑造这个时代的历史对这个时代的神学所表达的不容无视要求**。

传统的神学是这样的——在圣经中看到一个说法，然后在圣经中找到其他[说法印](https://www.zhihu.com/search?q=说法印&search_source=Entity&hybrid_search_source=Entity&hybrid_search_extra={"sourceType"%3A"answer"%2C"sourceId"%3A1213887662})证，通过一系列的印证，猜测这个问题的具体解答。现代神学是这样的——在圣经中看到一个说法，也在圣经中寻找其他相关的印证，然后把这一系列的说法的时代背景串起来，通过参考时代背景来思考上帝安排这些说法保留下来的原因，然后与整个世界运转的自然和人文规律去匹配。

这更类似被圣经里的苹果砸到头，然后在现实生活中做实验发现[万有引力定律](https://www.zhihu.com/search?q=万有引力定律&search_source=Entity&hybrid_search_source=Entity&hybrid_search_extra={"sourceType"%3A"answer"%2C"sourceId"%3A1213887662})。事实上万有引力定律的依据是实验，不是苹果。

所以，对现代神学而言，“圣经里如何说”并不能直接当做“事情就是如何”的根据，真正的根据是从圣经叙述指向的世界的事实。如果你拿掉最初的触发，仅仅只将被启发而找到的事实，这些事实本身就足以说明结论。

因此，在实际层面上，现代神学的结论是不依赖于圣经叙事的。对现代神学而言，圣经是一种丰富而绝对重要的思想遗产，作为启示的关键矿藏。

**神学所承认的世界历史，是从大爆炸开始的那个版本，与一般科学社区的共识完全一致，是遵从唯物史观的。也同样以科学作为研究历史鉴定历史的根本手段，其结论是完全不依赖于叙事的。**

**这甚至并不是现代神学才开始具有的新属性，而是除了“[原教旨主义神学](https://www.zhihu.com/search?q=原教旨主义神学&search_source=Entity&hybrid_search_source=Entity&hybrid_search_extra={"sourceType"%3A"answer"%2C"sourceId"%3A1213887662})”之外每一代的神学共同拥有的共性。**

**每个时代的神学，最终都是建立在它们所在时代最先进的[自然史观](https://www.zhihu.com/search?q=自然史观&search_source=Entity&hybrid_search_source=Entity&hybrid_search_extra={"sourceType"%3A"answer"%2C"sourceId"%3A1213887662})之上。在很多时代，它们本身就是最先进的自然史学的火车头。**

这是什么意思呢？意思是某个结论成立，不是因为某种故事情节的发展——比如“人有罪是因为人类的始祖当初在[伊甸园](https://www.zhihu.com/search?q=伊甸园&search_source=Entity&hybrid_search_source=Entity&hybrid_search_extra={"sourceType"%3A"answer"%2C"sourceId"%3A1213887662})犯了罪，然后上帝不原谅他们，然后就一代代遗传”。这种[原罪论](https://www.zhihu.com/search?q=原罪论&search_source=Entity&hybrid_search_source=Entity&hybrid_search_extra={"sourceType"%3A"answer"%2C"sourceId"%3A1213887662})，就是依赖叙事的。

[新神学](https://www.zhihu.com/search?q=新神学&search_source=Entity&hybrid_search_source=Entity&hybrid_search_extra={"sourceType"%3A"answer"%2C"sourceId"%3A1213887662})的理解却是这样的——圣经里提到了人有原罪、原罪必然导致堕落。那么就去查看人身上是否真的有这样的导致人类普遍犯罪的要素存在。找到并定位这样的要素，然后意识到这个要素就是“原罪”。

[人是否有原罪，为什么？1289 赞同 · 732 评论回答](https://www.zhihu.com/question/20760322/answer/588405939)

人有原罪，不是因为圣经这样说了，而是因为人确实有这样的属性。但要注意，这并不意味着圣经是无关紧要的，因为最初准确的指出这一点是非常重要的。

没有圣经去指引你这一点，你会没有最初的起点、最初的动念。

至于何谓“圣经”，又为何要以“圣经”为线索，可以看一下这个：

[天使是基督教的内容么？341 赞同 · 235 评论回答](https://www.zhihu.com/question/51459141/answer/521808148)

